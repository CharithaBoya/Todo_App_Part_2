document.addEventListener("DOMContentLoaded", function () {
    const todoItemsContainer = document.getElementById("todoItemsContainer");
    const addTodoButton = document.getElementById("addTodoButton");
    const completedTasksElement = document.getElementById("completedTasks");
    const totalTasksElement = document.getElementById("totalTasks");
    const API_URL = "http://localhost:8080/tasks";

    // Fetch the todo list from the backend
    async function fetchTodos() {
        try {
            const response = await fetch(API_URL);
            const todos = await response.json();
            return todos;
        } catch (error) {
            console.error("Error fetching todos:", error);
            return [];
        }
    }

    // Create a new todo on the backend
    async function createTodoOnBackend(task) {
        try {
            const response = await fetch(API_URL, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(task),
            });
            return await response.json();
        } catch (error) {
            console.error("Error creating todo:", error);
        }
    }

    // Update a todo on the backend
    async function toggleTodoCompletion(id, completed) {
        try {
            const response = await fetch(`${API_URL}/${id}/complete`, {
                method: "PATCH",
            });
            return await response.json();
        } catch (error) {
            console.error("Error toggling completion:", error);
        }
    }

    // Delete a todo on the backend
    async function deleteTodoOnBackend(id) {
        try {
            await fetch(`${API_URL}/${id}`, { method: "DELETE" });
        } catch (error) {
            console.error("Error deleting todo:", error);
        }
    }

    // Render the todo list
    async function renderTodos() {
        const todos = await fetchTodos();
        todoItemsContainer.innerHTML = "";

        todos.forEach((todo) => {
            createAndAppendTodo(todo);
        });

        updateTaskCounts(todos);
    }

    // Update task counts
    function updateTaskCounts(todos) {
        const completedCount = todos.filter((todo) => todo.completed).length;
        const totalCount = todos.length;

        completedTasksElement.textContent = `Completed: ${completedCount}`;
        totalTasksElement.textContent = `Total Tasks: ${totalCount}`;
    }

    // Handle adding a new todo
    async function onAddTodo() {
        const userInputElement = document.getElementById("todoUserInput");
        const userInputValue = userInputElement.value;

        if (userInputValue === "") {
            alert("Enter valid text");
            return;
        }

        const newTodo = {
            title: userInputValue,
            completed: false,
        };

        const createdTodo = await createTodoOnBackend(newTodo);
        if (createdTodo) {
            createAndAppendTodo(createdTodo);
            userInputElement.value = "";
        }

        renderTodos();
    }

    // Handle toggling todo completion
    async function onTodoStatusChange(id) {
        const updatedTodo = await toggleTodoCompletion(id);
        if (updatedTodo) {
            renderTodos();
        }
    }

    // Handle deleting a todo
    async function onDeleteTodo(id) {
        await deleteTodoOnBackend(id);
        renderTodos();
    }

    // Create and append a todo item
    function createAndAppendTodo(todo) {
        const todoElement = document.createElement("li");
        todoElement.classList.add("todo-item-container", "d-flex", "flex-row");
        todoElement.id = `todo-${todo.id}`;

        const inputElement = document.createElement("input");
        inputElement.type = "checkbox";
        inputElement.checked = todo.completed;

        inputElement.onclick = function () {
            onTodoStatusChange(todo.id);
        };

        inputElement.classList.add("checkbox-input");
        todoElement.appendChild(inputElement);

        const labelContainer = document.createElement("div");
        labelContainer.classList.add("label-container", "d-flex", "flex-row");
        todoElement.appendChild(labelContainer);

        const labelElement = document.createElement("label");
        labelElement.classList.add("checkbox-label");
        labelElement.textContent = todo.title;
        if (todo.completed) {
            labelElement.classList.add("checked");
        }
        labelContainer.appendChild(labelElement);

        const deleteIconContainer = document.createElement("div");
        deleteIconContainer.classList.add("delete-icon-container");
        labelContainer.appendChild(deleteIconContainer);

        const deleteIcon = document.createElement("i");
        deleteIcon.classList.add("fas", "fa-trash-alt", "delete-icon");

        deleteIcon.onclick = function () {
            onDeleteTodo(todo.id);
        };

        deleteIconContainer.appendChild(deleteIcon);

        todoItemsContainer.appendChild(todoElement);
    }

    // Initialize the app
    addTodoButton.onclick = onAddTodo;

    renderTodos();
});
